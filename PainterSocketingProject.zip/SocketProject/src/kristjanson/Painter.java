package kristjanson;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

@SuppressWarnings("serial")
public class Painter extends JFrame implements ActionListener, MouseListener, MouseMotionListener {
	PaintingPanel mp = new PaintingPanel();
	JPanel holder = new JPanel();
	private static int Port = 7000;
	// single socket
	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;
	private static JTextArea chatLog, txtArea;
	public Painter() {
		
		//ask user for name
		String name = JOptionPane.showInputDialog("Enter your name");
		holder.setName(name);
		
		setSize(500, 500);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		holder.setBackground(Color.WHITE);
		holder.setLayout(new BorderLayout());
		
		// paints create
		JPanel leftPanel = new JPanel();
		leftPanel.setLayout(new GridLayout(3, 1));
		
		// top button creates
		JPanel topPanel = new JPanel();
		topPanel.setLayout(new GridLayout(1, 2));
		
		// txt stuff
		JPanel chat = new JPanel();
		chat.setLayout(new BorderLayout());
		JButton send = new JButton("send");
		send.addActionListener(this);
		send.setActionCommand("send");
		chat.add(send, BorderLayout.EAST);
		txtArea = new JTextArea();
		
		chatLog = new JTextArea(3, 75);
		JScrollPane scrollPane = new JScrollPane(chatLog);
		
		chatLog.setEditable(false);
		chatLog.setBackground(Color.GRAY);
		chatLog.setPreferredSize(new Dimension(500, 75));
		chat.add(txtArea, BorderLayout.CENTER);
		//chat.add(chatLog, BorderLayout.SOUTH);
		chat.add(scrollPane, BorderLayout.SOUTH);
		
		// add red paint button
		JButton redPaint = new JButton();
		redPaint.setBackground(Color.RED);
		redPaint.setOpaque(true);
		redPaint.setBorderPainted(false);
		leftPanel.add(redPaint); // Added in next open cell in the grid
		redPaint.setActionCommand("red");
		redPaint.addActionListener(this);
		
		// green
		JButton greenPaint = new JButton();
		greenPaint.setBackground(Color.GREEN);
		greenPaint.setOpaque(true);
		greenPaint.setBorderPainted(false);
		leftPanel.add(greenPaint); // Added in next open cell in the grid
		greenPaint.setActionCommand("green");
		greenPaint.addActionListener(this);
		
		// blue
		JButton bluePaint = new JButton();
		bluePaint.setBackground(Color.BLUE);
		bluePaint.setOpaque(true);
		bluePaint.setBorderPainted(false);
		leftPanel.add(bluePaint); // Added in next open cell in the grid
		bluePaint.setActionCommand("blue");
		bluePaint.addActionListener(this);
		
		// add panels to holder
		holder.add(leftPanel, BorderLayout.WEST);
		holder.add(topPanel, BorderLayout.NORTH);
		holder.add(chat, BorderLayout.SOUTH);
		
		// add old messages to board
		Button line = new Button("Line");
		topPanel.add(line);
		Button circle = new Button("Circle");
		topPanel.add(circle);
		circle.setActionCommand("circle");
		line.setActionCommand("line");
		circle.addActionListener(this);
		line.addActionListener(this);
		mp.addMouseListener(this);
		holder.add(mp, BorderLayout.CENTER);
		setContentPane(holder);
		setVisible(true);
	}
	// add main
	Color currentCol = Color.red;
	int currentPrim = 1;
	@Override
	public void actionPerformed(ActionEvent e) {
		
		//add in functionality sending strings from chat
		String action = e.getActionCommand();
		
		try {
			if(action.equals("send")) {
			oos.writeObject(holder.getName() + ": " + txtArea.getText());
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (action.equals("red")) {
			System.out.println("red butt");
			currentCol = Color.red;
		}
		if (action.equals("blue")) {
			System.out.println("blue butt");
			currentCol = Color.blue;
		}
		if (action.equals("green")) {
			System.out.println("green butt");
			currentCol = Color.green;
		}
		if (action.equals("line")) {
			System.out.println("line butt");
			currentPrim = 1;
		}
		if (action.equals("circle")) {
			System.out.println("circle butt");
			currentPrim = 0;
		}
	}
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	// Point mouseLoc =
	Point start;
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		start = new Point(e.getX(), e.getY());
		
		System.out.println(start);
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		Point mouseLoc = new Point(e.getX(), e.getY());
		if (currentPrim == 0) {
			Circle cir = new Circle(currentCol, start, mouseLoc);			
			try {
				oos.writeObject(cir);
				//cir = (Circle)ois.readObject();
			} catch (IOException  e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			mp.addPrimitive(cir);
	
		} else if (currentPrim == 1) {
			Line line = new Line(currentCol, start, mouseLoc);					
			try {
				oos.writeObject(line);
				//line = (Line)ois.readObject();
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}			
			
			mp.addPrimitive(line);
			System.out.println(mouseLoc);
		}
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	void getString(Object o) {
		//get string from thread, send to chat
		System.out.println((String) o + "\n");
		chatLog.append((String) o + "\n");
		chatLog.update(chatLog.getGraphics());
	}
	void getPainting(Object o) {
		// get prim from thread, draw it
		mp.addPrimitive((PaintingPrimatives)o);
	}
	public static void main(String[] args) {
		Painter p = new Painter();
		try {
			System.out.println("calling");
			s = new Socket("localHost", Port);
			System.out.println("Connected");
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			
			//put code to import existing drawings and strings here
			
			painterThread pT = new painterThread(p, ois);
			pT.startThread();
		} catch (IOException e) {
			System.out.println("issue with node");
			e.printStackTrace();
		}
		
	}
}
