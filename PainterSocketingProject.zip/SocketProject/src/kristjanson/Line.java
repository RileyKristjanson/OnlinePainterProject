package kristjanson;

import java.awt.*;
import java.io.Serializable;


public class Line extends PaintingPrimatives {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Point start;
	Point end;
	
	public Line(Color col, Point s, Point e) {
		super(col);
		// TODO Auto-generated constructor stub
		start = s;
		end = e;
	}

	@Override
	protected void drawGeometry(Graphics g) {
		
		g.drawLine(start.x, start.y,end.x,end.y);
		
	}



	@Override
	public void draw(Graphics g) {
		
		g.setColor(this.myColor);
		drawGeometry(g);
		
	}

}
