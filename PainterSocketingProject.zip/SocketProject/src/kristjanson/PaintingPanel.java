package kristjanson;

import java.awt.*;
import java.util.ArrayList;
import java.util.EmptyStackException;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PaintingPanel extends JPanel{
	
	
	ArrayList<PaintingPrimatives> primitives = new ArrayList<PaintingPrimatives>();
	
	public PaintingPanel() {
		
		this.setBackground(Color.LIGHT_GRAY);
	}
	
	public synchronized void addPrimitive(PaintingPrimatives obj) {
		this.primitives.add(obj);
		repaint();
		
	}

	public synchronized void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		 for(PaintingPrimatives obj : primitives) { 
             obj.draw(g);
		 }
	}
	
}
