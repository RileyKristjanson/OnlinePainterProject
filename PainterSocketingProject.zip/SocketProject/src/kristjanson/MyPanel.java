package kristjanson;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class MyPanel extends JPanel {
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//g.setColor(Color.BLUE);
		System.out.println("PC called");
	}
}
