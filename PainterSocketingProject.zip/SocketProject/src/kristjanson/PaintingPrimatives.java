package kristjanson;
import java.awt.*;
import java.io.Serializable;

public abstract class PaintingPrimatives implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Color myColor;
	
	public PaintingPrimatives(Color col) {
		
		myColor = col;
	}
	
	public abstract void draw(Graphics g);
	
	protected abstract void drawGeometry(Graphics g);
}
