package kristjanson;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.SocketException;

public class hubThread implements Runnable{

	Hub theHub;
	ObjectInputStream OIS;
	ObjectOutputStream OOS;
	
	public hubThread(Hub hub, ObjectInputStream ois, ObjectOutputStream oos) {
		
		theHub = hub;
		OIS = ois;
		OOS = oos;
	}
	
	public void run() {
		
		try {
			while(true) {
				Object o = OIS.readObject(); //corrupted for some reason
				theHub.sendToPainters(o);
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SocketException e) {
			theHub.painterDisconnect(OOS);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
			
	}
	public void startThread() {
		Thread th = new Thread(this);
		th.start();
	}
}
