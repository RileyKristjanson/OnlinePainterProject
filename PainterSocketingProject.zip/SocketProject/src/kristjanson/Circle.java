package kristjanson;

import java.awt.*;


public class Circle extends PaintingPrimatives{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Point center;
	Point radiusPoint;
	
	public Circle(Color col, Point c, Point RP) {
		super(col);
		// TODO Auto-generated constructor stub
		center = c;
		radiusPoint = RP;
	}

	@Override
	public void draw(Graphics g) {
		
		g.setColor(this.myColor);
		drawGeometry(g);
		
	}

	@Override
	protected void drawGeometry(Graphics g) {
		
		int radius = (int) Math.abs(center.distance(radiusPoint));
        g.drawOval(center.x - radius, center.y - radius, radius*2, radius*2);           
		
	}

}
