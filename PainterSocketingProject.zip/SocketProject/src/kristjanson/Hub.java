package kristjanson;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
public class Hub {
	
	private ArrayList<ObjectOutputStream> outputs;
	private ArrayList<PaintingPrimatives> primitives;
	private ArrayList<String> messages;
	ServerSocket ss;
	public Hub() {
		primitives = new ArrayList<PaintingPrimatives>();
		outputs = new ArrayList<ObjectOutputStream>();
		messages = new ArrayList<String>();
		try {
			ss = new ServerSocket(7000);
			while (true) {
				System.out.println("Waiting");
				Socket s = ss.accept();
				System.out.println("Accepted!");
				ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream()); // reads the output
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				outputs.add(oos); // stores in the array list from the read objects
				
				for(int i = 0; i < primitives.size(); i++) {
					oos.writeObject(primitives.get(i)); // writes the objects stored in the arrays back to the client
				}
				for(int i = 0; i < messages.size(); i++) {
					oos.writeObject(messages.get(i)); // writes the objects stored in the arrays back to the client
				}
				// makes a thread to handle this hub
				hubThread ht = new hubThread(this, ois, oos);
				ht.startThread();
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public synchronized void sendToPainters(Object obj) {
		try {
			for (int i = 0; i < outputs.size(); i++) {
				if (!outputs.get(i).equals(obj)) { // checks duplicates
					outputs.get(i).writeObject(obj); // writes object to painters
				}
			}
			// add object too primitive or message array
			if (obj instanceof PaintingPrimatives) {
				primitives.add((PaintingPrimatives) obj);
			} else if (obj instanceof String) {
				messages.add((String) obj);
			}
		} catch (IOException e) {
		}
	}
	public void painterDisconnect(ObjectOutputStream oos) {
		for (int i = 0; i < outputs.size(); i++) {
			if (outputs.get(i).equals(oos)) {
				outputs.remove(i);
			}
		}
	}
	public static void main(String[] args) {
		new Hub();
	}
}