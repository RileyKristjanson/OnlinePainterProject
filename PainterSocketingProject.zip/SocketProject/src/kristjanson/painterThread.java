package kristjanson;

import java.io.IOException;
import java.io.ObjectInputStream;

/*
 * gets info from hub, sends that out to painters
 * have one of these for each painter
 *
 */
public class painterThread implements Runnable {
	private Painter p;
	private ObjectInputStream ois;

	public painterThread(Painter p, ObjectInputStream ois) {
		this.p = p;
		this.ois = ois;
	}

	@Override
	public void run() {
		Object o;
		try {
			while (true) {
				o = (Object) ois.readObject();
				if (o instanceof PaintingPrimatives) {
					p.getPainting(o);
				} else if (o instanceof String) {
					p.getString(o);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void startThread() {
		Thread th = new Thread(this);
		th.start();
	}
}
